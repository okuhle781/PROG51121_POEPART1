/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/**
 *
 * @author Student
 */

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("===== Registration =====");

        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter South African cell phone number: ");
        String cellPhone = scanner.nextLine();

        Login user = new Login(
                username,
                password,
                cellPhone,
                firstName,
                lastName
        );

        System.out.println(user.registerUser());

        if (user.checkUserName()) {
            System.out.println("Username successfully captured.");
        }

        if (user.checkPasswordComplexity()) {
            System.out.println("Password successfully captured.");
        }

        if (user.checkCellPhoneNumber()) {
            System.out.println("Cell number successfully captured.");
        }

        System.out.println("\n===== Login =====");

        System.out.print("Enter username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = scanner.nextLine();

        System.out.println(
                user.returnLoginStatus(loginUsername, loginPassword)
        );

        scanner.close();
    }
}
