/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.logintest1;

/**
 *
 * @author Student
*/

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class LoginTest {

    @Test
    public void testCorrectUsername() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");

        assertTrue(user.checkUserName());
    }

    @Test
    public void testIncorrectUsername() {
        Login user = new Login("kyle!!!!!!1!", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");

        assertFalse(user.checkUserName());
    }

    public LoginTest() {
    }

    @Test
    public void testCorrectPassword() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");

        assertTrue(user.checkPasswordComplexity());
    }

    @Test
    public void testIncorrectPassword() {
        Login user = new Login("kyl_1", "password", "+27838968976", "Kyle", "Smith");

        assertFalse(user.checkPasswordComplexity());
    }

    @Test
    public void testCorrectCellPhone() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");

        assertTrue(user.checkCellPhoneNumber());
    }

    @Test
    public void testIncorrectCellPhone() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "08966553", "Kyle", "Smith");

        assertFalse(user.checkCellPhoneNumber());
    }

    @Test
    public void testSuccessfulLogin() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");

        assertTrue(user.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testUnsuccessfulLogin() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");

        assertFalse(user.loginUser("wrong", "wrong"));
    }
}
