/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class NewClass {
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class LoginTest {

    Login user = new Login(
            "kyl_1",
            "Ch&&sec@ke99!",
            "+27838968976",
            "Kyle",
            "Smith"
    );

    // ==============================
    // assertEquals Tests
    // ==============================

    @Test
    public void testCorrectUsername() {
        Login testUser = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertEquals(
                true,
                testUser.checkUserName()
        );
    }

    @Test
    public void testIncorrectUsername() {
        Login testUser = new Login(
                "kyle!!!!!!1!",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertEquals(
                false,
                testUser.checkUserName()
        );
    }

    @Test
    public void testCorrectPassword() {
        Login testUser = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertEquals(
                true,
                testUser.checkPasswordComplexity()
        );
    }

    @Test
    public void testIncorrectPassword() {
        Login testUser = new Login(
                "kyl_1",
                "password",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertEquals(
                false,
                testUser.checkPasswordComplexity()
        );
    }

    @Test
    public void testCorrectCellPhone() {
        Login testUser = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertEquals(
                true,
                testUser.checkCellPhoneNumber()
        );
    }

    @Test
    public void testIncorrectCellPhone() {
        Login testUser = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "08966553",
                "Kyle",
                "Smith"
        );

        assertEquals(
                false,
                testUser.checkCellPhoneNumber()
        );
    }

    // ==============================
    // assertTrue / assertFalse Tests
    // ==============================

    @Test
    public void testSuccessfulLogin() {
        assertTrue(
                user.loginUser("kyl_1", "Ch&&sec@ke99!")
        );
    }

    @Test
    public void testFailedLogin() {
        assertFalse(
                user.loginUser("wrong_user", "wrong_password")
        );
    }

    @Test
    public void testUsernameCorrect() {
        assertTrue(user.checkUserName());
    }

    @Test
    public void testUsernameIncorrect() {
        Login testUser = new Login(
                "kyle!!!!!!1!",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertFalse(testUser.checkUserName());
    }

    @Test
    public void testPasswordCorrect() {
        assertTrue(user.checkPasswordComplexity());
    }

    @Test
    public void testPasswordIncorrect() {
        Login testUser = new Login(
                "kyl_1",
                "password",
                "+27838968976",
                "Kyle",
                "Smith"
        );

        assertFalse(testUser.checkPasswordComplexity());
    }

    @Test
    public void testCellPhoneCorrect() {
        assertTrue(user.checkCellPhoneNumber());
    }

    @Test
    public void testCellPhoneIncorrect() {
        Login testUser = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "08966553",
                "Kyle",
                "Smith"
        );

        assertFalse(testUser.checkCellPhoneNumber());
    }
}    
}
